DEFAULT_AUTH_URL  = "https://sso.redhat.com/auth/"
DEFAULT_CLIENT_ID = "cloud-services"
REALM_NAME = "redhat-external"
